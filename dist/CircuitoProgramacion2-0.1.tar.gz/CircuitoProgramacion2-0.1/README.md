# CircuitoProgramacion2
 #Este proyecto se baso en este ejercicio que aparece y pudimos hacer que cada persona la cual tenga este mismo ejercicio pero diferente numeros pueda allar, el resultado.
[![Whats-App-Image-2022-09-24-at-12-20-36-AM.jpg](https://i.postimg.cc/43KxX4ZS/Whats-App-Image-2022-09-24-at-12-20-36-AM.jpg)](https://postimg.cc/QB33b3FQ)

